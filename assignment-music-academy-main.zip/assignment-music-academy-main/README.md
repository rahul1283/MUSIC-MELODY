# Simple Page of 'Educational Service' (Melody Music Academy) - Assignment (Milestone - 9)

* This Assignment is mainly on `React Router` along with `Custom 404 Error Page`

* As a Basic `React Router` Assignment , We had to Put 04 (Four) Routes (minimum)

* Simple `Animation` is added in Home (Navabar) button. 

* [Click Here for Live Link / Website  (Netlify)](https://assignment-music-academy.netlify.app/)

* Screenshot of Live Site -

![alt text](public/demo.png)


### Technology Used

* React JS
* React Router
* Google Crome Developer Tool
* Custom JSON
* Tailwind CDN
* JavaScript (ES6)
* Fontawesome 6 Beta
