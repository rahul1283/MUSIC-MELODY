import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router';
import NotFound from '../NotFound/NotFound';

const CourseDetails = () => {

    return (
        <div>
            <br />
            <NotFound></NotFound>
        </div>
    );
};

export default CourseDetails;